﻿using Newtonsoft.Json;
using System;

namespace DemoASPNetCore.Models
{
     public class Workout
     {


          [JsonIgnore]
          public string UserId
          {
               get; set;
          }
          public int Id
          {
               get; set;
          }
          public DateTimeOffset Date
          {
               get; set;
          }

          public int DistanceInMeters
          {
               get; set;
          }

          public long TimeInSeconds
          {
               get; set;
          }
     }
}
